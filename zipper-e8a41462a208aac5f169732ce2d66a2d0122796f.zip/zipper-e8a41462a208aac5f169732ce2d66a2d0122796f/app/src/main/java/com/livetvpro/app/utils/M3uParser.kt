package com.livetvpro.app.utils

import android.util.Base64
import com.livetvpro.app.data.models.Channel
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

object M3uParser {

    data class M3uChannel(
        val name: String,
        val logoUrl: String,
        val streamUrl: String,
        val groupTitle: String = "",
        val userAgent: String? = null,
        val httpHeaders: Map<String, String> = emptyMap(),
        val drmScheme: String? = null,
        val drmKeyId: String? = null,
        val drmKey: String? = null
    )

    private val PIPE_PARAM_PATTERN    = Regex("[&?]([^=]+)=(?:%7C|\\|)([^=]+)=([^&]+)")
    private val JSON_HEADER_PATTERN   = Regex("[&?](headers?|hdr|h)=(%7B[^&]+|\\{[^&]+)")
    private val COOKIE_MULTI_PATTERN  = Regex("[&?](c|cookie)\\d+=([^&]+)")
    private val DOUBLE_COLON_PATTERN  = Regex("::([^:=]+)=([^:]+)")
    private val PIPE_SPLIT_PATTERN    = Regex("[&|]")
    private val AMP_SPLIT_PATTERN     = Regex("[&|;]")
    private val TRAILING_SEP_PATTERN  = Regex("[&?]+$")
    private val QUESTION_AMP_PATTERN  = Regex("\\?&")
    private val JWK_KID_PATTERN       = Regex(""""kid"\s*:\s*"([^"]+)"""")
    private val JWK_K_PATTERN         = Regex(""""k"\s*:\s*"([^"]+)"""")
    private val BASE64_URL_PATTERN    = Regex("([?&])(url|u|target|dest|destination|link|redirect|goto)=([A-Za-z0-9+/=_-]{20,})")
    private val PROXY_D_PARAM_PATTERN = Regex("[?&]d=([^&]+)")
    private val HMA_URL_PATTERN       = Regex("[?&](url|u|target)=([^&]+)")
    private val KPROXY_PATTERN        = Regex("kproxy\\.com/\\?([^&]+)")
    private val HIDE_ME_PATTERN       = Regex("[?&]u=([^&]+)")
    private val CROXY_PATTERN         = Regex("croxyproxy\\.com/\\?url=([^&]+)")

    private val BASE64_PARAM_PATTERNS = listOf("data", "meta", "params", "h", "headers", "b64", "encoded")
        .map { name -> name to Regex("[&?]$name=([A-Za-z0-9+/=_-]{20,})") }

    private val COMMON_HEADER_PARAMS = mapOf(
        "ua"             to "User-Agent",
        "user-agent"     to "User-Agent",
        "useragent"      to "User-Agent",
        "ref"            to "Referer",
        "referer"        to "Referer",
        "referrer"       to "Referer",
        "cookie"         to "Cookie",
        "cookies"        to "Cookie",
        "origin"         to "Origin",
        "xff"            to "X-Forwarded-For",
        "x-forwarded-for" to "X-Forwarded-For",
        "range"          to "Range",
        "accept"         to "Accept"
    )
    private val COMMON_HEADER_PATTERNS: Map<String, Pair<String, Regex>> =
        COMMON_HEADER_PARAMS.entries.associate { (param, header) ->
            param to (header to Regex("[&?]$param=([^&]+)", RegexOption.IGNORE_CASE))
        }

    private val ATTR_PATTERN_CACHE = mutableMapOf<String, Pair<Regex, Regex>>()
    private fun attributePatterns(attribute: String): Pair<Regex, Regex> =
        ATTR_PATTERN_CACHE.getOrPut(attribute) {
            Regex("""$attribute="([^"]*)"""") to Regex("""$attribute=([^ ]*)""")
        }

    fun isXtreamUrl(url: String): Boolean {
        val lower = url.lowercase()
        return (lower.contains("/get.php") || lower.contains("/player_api.php")) &&
                lower.contains("username=") && lower.contains("password=")
    }

    fun normalizeXtreamUrl(url: String): String {
        return try {
            val decoded = try { java.net.URLDecoder.decode(url, "UTF-8") } catch (_: Exception) { url }
            val queryStart = decoded.indexOf('?').takeIf { it != -1 } ?: return url
            val params = decoded.substring(queryStart + 1).split('&').associate { part ->
                val eq = part.indexOf('=')
                if (eq == -1) part to "" else part.substring(0, eq) to part.substring(eq + 1)
            }
            val username = params["username"] ?: return url
            val password = params["password"] ?: return url
            val schemeEnd = decoded.indexOf("//") + 2
            val pathStart = decoded.indexOf('/', schemeEnd).takeIf { it != -1 } ?: return url
            val baseUrl = decoded.substring(0, pathStart)
            "$baseUrl/get.php?username=$username&password=$password&type=m3u_plus&output=m3u8"
        } catch (_: Exception) { url }
    }

    suspend fun parseM3uFromUrl(m3uUrl: String): List<M3uChannel> {
        val trimmedUrl = if (isXtreamUrl(m3uUrl.trim())) {
            normalizeXtreamUrl(m3uUrl.trim())
        } else {
            m3uUrl.trim()
        }

        if (trimmedUrl.startsWith("[") || trimmedUrl.startsWith("{")) {
            return parseJsonPlaylist(trimmedUrl)
        }

        android.util.Log.d("M3uParser", "Fetching playlist from: $trimmedUrl")

        val url = URL(trimmedUrl)
        val connection = url.openConnection() as HttpURLConnection
        connection.requestMethod = "GET"
        connection.connectTimeout = 30000
        connection.readTimeout = 30000

        connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36")
        connection.setRequestProperty("Accept", "*/*")
        connection.setRequestProperty("Accept-Language", "en-GB,en-US;q=0.9,en;q=0.8")
        connection.setRequestProperty("Connection", "keep-alive")

        connection.instanceFollowRedirects = true
        HttpURLConnection.setFollowRedirects(true)

        val responseCode = connection.responseCode
        android.util.Log.d("M3uParser", "Response code: $responseCode")

        if (responseCode == HttpURLConnection.HTTP_OK) {
            val contentType = connection.contentType
            android.util.Log.d("M3uParser", "Content-Type: $contentType")

            val encoding = connection.contentEncoding
            val inputStream = if (encoding?.equals("gzip", ignoreCase = true) == true) {
                java.util.zip.GZIPInputStream(connection.inputStream)
            } else {
                connection.inputStream
            }
            val reader = BufferedReader(InputStreamReader(inputStream))
            val content = reader.readText()
            reader.close()
            connection.disconnect()

            android.util.Log.d("M3uParser", "Content length: ${content.length} bytes")
            if (content.isNotEmpty()) {
                android.util.Log.d("M3uParser", "First 200 chars: ${content.take(200)}")
            }

            if (content.isBlank()) {
                android.util.Log.e("M3uParser", "Empty response from server")
                return emptyList()
            }

            val trimmedContent = content.trim()

            if (trimmedContent.startsWith("[") || trimmedContent.startsWith("{")) {
                android.util.Log.d("M3uParser", "Detected JSON format")
                return parseJsonPlaylist(trimmedContent)
            }

            if (trimmedContent.startsWith("<!DOCTYPE", ignoreCase = true) ||
                trimmedContent.startsWith("<html", ignoreCase = true) ||
                trimmedContent.startsWith("<?xml", ignoreCase = true)) {
                android.util.Log.e("M3uParser", "Server returned HTML/XML instead of M3U playlist")
                android.util.Log.e("M3uParser", "Response preview: ${content.take(500)}")
                return emptyList()
            }

            if (!trimmedContent.contains("#EXTM3U", ignoreCase = true) &&
                !trimmedContent.contains("#EXTINF", ignoreCase = true) &&
                !trimmedContent.startsWith("http", ignoreCase = true)) {
                android.util.Log.w("M3uParser", "Content doesn't look like standard M3U format")
                android.util.Log.w("M3uParser", "Content preview: ${content.take(300)}")
            }

            val channels = parseM3uContent(content)
            android.util.Log.d("M3uParser", "Successfully parsed ${channels.size} channels")

            if (channels.isEmpty()) {
                android.util.Log.w("M3uParser", "No channels found in playlist")
            }

            return channels

        } else if (responseCode == HttpURLConnection.HTTP_UNAUTHORIZED) {
            android.util.Log.e("M3uParser", "Authentication failed (401). Check username/password in URL")
            throw java.io.IOException("HTTP 401: Authentication failed")

        } else if (responseCode == HttpURLConnection.HTTP_FORBIDDEN) {
            android.util.Log.e("M3uParser", "Access forbidden (403). Server denied access")
            throw java.io.IOException("HTTP 403: Access denied")

        } else if (responseCode == HttpURLConnection.HTTP_NOT_FOUND) {
            android.util.Log.e("M3uParser", "Playlist not found (404). Check URL path")
            throw java.io.IOException("HTTP 404: Playlist not found")

        } else if (responseCode >= 500) {
            android.util.Log.e("M3uParser", "Server error ($responseCode). Server is having issues")
            throw java.io.IOException("HTTP $responseCode: Server error")

        } else {
            android.util.Log.e("M3uParser", "HTTP error: $responseCode")
            throw java.io.IOException("HTTP $responseCode: ${connection.responseMessage ?: "Request failed"}")
        }
    }


    fun parseJsonPlaylist(jsonContent: String): List<M3uChannel> {
        val channels = mutableListOf<M3uChannel>()
        try {
            val trimmed = jsonContent.trim()

            val jsonArray = if (trimmed.startsWith("[")) {
                JSONArray(trimmed)
            } else if (trimmed.startsWith("{")) {
                val jsonObject = JSONObject(trimmed)
                when {
                    jsonObject.has("channels") -> jsonObject.getJSONArray("channels")
                    jsonObject.has("items")    -> jsonObject.getJSONArray("items")
                    jsonObject.has("data")     -> jsonObject.getJSONArray("data")
                    else -> return emptyList()
                }
            } else {
                return emptyList()
            }

            for (i in 0 until jsonArray.length()) {
                val item = jsonArray.getJSONObject(i)

                val name = item.optString("name", "Unknown Channel")
                var link = item.optString("link", "")
                    .ifEmpty { item.optString("url", "") }
                    .ifEmpty { item.optString("stream", "") }
                    .ifEmpty { item.optString("streamUrl", "") }

                val logo = item.optString("logo", "")
                    .ifEmpty { item.optString("logoUrl", "") }
                    .ifEmpty { item.optString("icon", "") }

                val category = item.optString("category", "")
                    .ifEmpty { item.optString("group", "") }

                val cookie    = item.optString("cookie", "")
                val userAgent = item.optString("user-agent", null)
                    ?: item.optString("user_agent", null)
                    ?: item.optString("userAgent", null)
                val referer   = item.optString("referer", null)
                    ?: item.optString("referrer", null)
                val origin    = item.optString("origin", null)

                val headers = mutableMapOf<String, String>()
                if (cookie.isNotEmpty()) headers["Cookie"] = cookie
                referer?.let { headers["Referer"] = it }
                origin?.let  { headers["Origin"]  = it }

                link = decodeProxyUrl(link)

                var drmScheme = item.optString("drmScheme", null)
                    ?: item.optString("drm_scheme", null)
                    ?: item.optString("drm", null)

                var drmKeyId: String? = null
                var drmKey: String?   = null

                val drmLicense = item.optString("drmLicense", null)
                    ?: item.optString("drm_license", null)
                    ?: item.optString("license", null)

                if (drmLicense != null && drmLicense.isNotEmpty()) {
                    if (drmLicense.startsWith("http://", ignoreCase = true) ||
                        drmLicense.startsWith("https://", ignoreCase = true)) {
                        drmKeyId = drmLicense
                        drmKey   = "LICENSE_URL"
                    } else if (drmLicense.contains(":")) {
                        val parts = drmLicense.split(":", limit = 2)
                        if (parts.size == 2) {
                            drmKeyId = parts[0].trim()
                            drmKey   = parts[1].trim()
                        }
                    }
                }

                if (drmScheme != null) {
                    drmScheme = normalizeDrmScheme(drmScheme)
                }

                if (link.isNotEmpty()) {
                    channels.add(M3uChannel(
                        name       = name,
                        logoUrl    = logo,
                        streamUrl  = link,
                        groupTitle = category,
                        userAgent  = userAgent,
                        httpHeaders = headers,
                        drmScheme  = drmScheme,
                        drmKeyId   = drmKeyId,
                        drmKey     = drmKey
                    ))
                }
            }

        } catch (e: Exception) {
        }
        return channels
    }

    private fun decodeProxyUrl(url: String): String {
        if (url.isEmpty()) return url

        try {
            if (url.contains("proxysite.com/process.php"))        return decodeProxySiteUrl(url)
            if (url.contains("hidemyass.com") || url.contains("hma.com")) return decodeHMAProxyUrl(url)
            if (url.contains("/process.php") && url.contains("d=")) return decodeGenericProxyUrl(url)
            if (url.contains("kproxy.com"))    return decodeKProxyUrl(url)
            if (url.contains("hide.me/proxy")) return decodeHideMeProxyUrl(url)
            if (url.contains("croxyproxy.com")) return decodeCroxyProxyUrl(url)

            val base64Match = BASE64_URL_PATTERN.find(url)
            if (base64Match != null) {
                try {
                    val encoded = base64Match.groupValues[3]
                    val decoded = try {
                        String(Base64.decode(encoded, Base64.URL_SAFE or Base64.NO_WRAP))
                    } catch (e: Exception) {
                        String(Base64.decode(encoded, Base64.DEFAULT))
                    }
                    if (decoded.startsWith("http", ignoreCase = true)) return decoded
                } catch (e: Exception) {}
            }

        } catch (e: Exception) {
        }

        return url
    }

    private fun decodeProxySiteUrl(url: String): String {
        return try {
            val dParamMatch = PROXY_D_PARAM_PATTERN.find(url) ?: return url
            val urlDecoded  = java.net.URLDecoder.decode(dParamMatch.groupValues[1], "UTF-8")
            val decoded     = try {
                String(Base64.decode(urlDecoded, Base64.URL_SAFE or Base64.NO_WRAP))
            } catch (e: Exception) {
                String(Base64.decode(urlDecoded, Base64.DEFAULT))
            }
            if (decoded.startsWith("http", ignoreCase = true)) decoded else url
        } catch (e: Exception) { url }
    }

    private fun decodeGenericProxyUrl(url: String): String {
        return try {
            val dParamMatch = PROXY_D_PARAM_PATTERN.find(url) ?: return url
            val decoded     = java.net.URLDecoder.decode(dParamMatch.groupValues[1], "UTF-8")
            val base64Decoded = try {
                String(Base64.decode(decoded, Base64.URL_SAFE or Base64.NO_WRAP))
            } catch (e: Exception) {
                String(Base64.decode(decoded, Base64.DEFAULT))
            }
            if (base64Decoded.startsWith("http", ignoreCase = true)) base64Decoded else url
        } catch (e: Exception) { url }
    }

    private fun decodeHMAProxyUrl(url: String): String {
        return try {
            val match = HMA_URL_PATTERN.find(url) ?: return url
            val decoded = java.net.URLDecoder.decode(match.groupValues[2], "UTF-8")
            if (decoded.startsWith("http", ignoreCase = true)) decoded else url
        } catch (e: Exception) { url }
    }

    private fun decodeKProxyUrl(url: String): String {
        return try {
            val match = KPROXY_PATTERN.find(url) ?: return url
            val decoded = java.net.URLDecoder.decode(match.groupValues[1], "UTF-8")
            if (decoded.startsWith("http", ignoreCase = true)) decoded else url
        } catch (e: Exception) { url }
    }

    private fun decodeHideMeProxyUrl(url: String): String {
        return try {
            val match   = HIDE_ME_PATTERN.find(url) ?: return url
            val encoded = match.groupValues[1]
            val decoded = try {
                String(Base64.decode(encoded, Base64.URL_SAFE or Base64.NO_WRAP))
            } catch (e: Exception) {
                java.net.URLDecoder.decode(encoded, "UTF-8")
            }
            if (decoded.startsWith("http", ignoreCase = true)) decoded else url
        } catch (e: Exception) { url }
    }

    private fun decodeCroxyProxyUrl(url: String): String {
        return try {
            val match = CROXY_PATTERN.find(url) ?: return url
            val decoded = java.net.URLDecoder.decode(match.groupValues[1], "UTF-8")
            if (decoded.startsWith("http", ignoreCase = true)) decoded else url
        } catch (e: Exception) { url }
    }

    fun parseM3uContent(content: String): List<M3uChannel> {
        val channels = ArrayList<M3uChannel>(1024)

        var currentName      = ""
        var currentLogo      = ""
        var currentGroup     = ""
        var currentUserAgent: String? = null
        var currentHeaders   = mutableMapOf<String, String>()
        var currentDrmScheme: String? = null
        var currentDrmKeyId: String?  = null
        var currentDrmKey: String?    = null

        content.reader().forEachLine { line ->
            val trimmedLine = line.trim()
            if (trimmedLine.isEmpty() || trimmedLine.startsWith("#EXTM3U")) return@forEachLine

            when {
                trimmedLine.startsWith("#KODIPROP:inputstream.adaptive.license_type=") -> {
                    val rawScheme = trimmedLine.substringAfter("=").trim().lowercase()
                    currentDrmScheme = normalizeDrmScheme(rawScheme)
                }

                trimmedLine.startsWith("#KODIPROP:inputstream.adaptive.license_key=") -> {
                    val keyValue = trimmedLine.substringAfter("=").trim()
                    when {
                        keyValue.startsWith("http://", ignoreCase = true) ||
                        keyValue.startsWith("https://", ignoreCase = true) -> {
                            currentDrmKeyId = keyValue
                            currentDrmKey   = "LICENSE_URL"
                        }
                        keyValue.contains(":") && !keyValue.startsWith("{") -> {
                            val parts = keyValue.split(":", limit = 2)
                            if (parts.size == 2) {
                                currentDrmKeyId = parts[0].trim()
                                currentDrmKey   = parts[1].trim()
                            }
                        }
                        keyValue.startsWith("{") -> {
                            val (keyId, key) = parseJWKToKeyIdPair(keyValue)
                            if (keyId != null && key != null) {
                                currentDrmKeyId = keyId
                                currentDrmKey   = key
                            }
                        }
                    }
                }

                trimmedLine.startsWith("#EXTINF:") -> {
                    currentUserAgent = null
                    currentHeaders   = mutableMapOf()
                    currentName      = extractChannelName(trimmedLine)
                    currentLogo      = extractAttribute(trimmedLine, "tvg-logo")
                    currentGroup     = extractAttribute(trimmedLine, "group-title")
                }

                trimmedLine.startsWith("#EXTVLCOPT:http-user-agent=") -> {
                    currentUserAgent = trimmedLine.substringAfter("=").trim()
                }

                trimmedLine.startsWith("#EXTVLCOPT:http-origin=") -> {
                    currentHeaders["Origin"] = trimmedLine.substringAfter("=").trim()
                }

                trimmedLine.startsWith("#EXTVLCOPT:http-referrer=") -> {
                    currentHeaders["Referer"] = trimmedLine.substringAfter("=").trim()
                }

                trimmedLine.startsWith("#EXTVLCOPT:http-cookie=") -> {
                    currentHeaders["Cookie"] = trimmedLine.substringAfter("=").trim()
                }

                trimmedLine.startsWith("#EXTVLCOPT:http-header-add=") -> {
                    val raw = trimmedLine.substringAfter("=").trim()
                    val colonIdx = raw.indexOf(':')
                    if (colonIdx != -1) {
                        val key   = raw.substring(0, colonIdx).trim()
                        val value = raw.substring(colonIdx + 1).trim()
                        currentHeaders[key] = value
                    }
                }

                trimmedLine.startsWith("#EXTHTTP:") -> {
                    try {
                        val jsonPart = trimmedLine.substringAfter("#EXTHTTP:").trim()
                        if (jsonPart.startsWith("{")) {
                            val json = JSONObject(jsonPart)
                            json.keys().forEach { key ->
                                val value = json.optString(key, "")
                                when (key.lowercase()) {
                                    "cookie"            -> currentHeaders["Cookie"] = value
                                    "user-agent"        -> currentUserAgent = value
                                    "referer","referrer"-> currentHeaders["Referer"] = value
                                    "origin"            -> currentHeaders["Origin"] = value
                                    else                -> currentHeaders[key] = value
                                }
                            }
                        }
                    } catch (e: Exception) {}
                }

                !trimmedLine.startsWith("#") -> {
                    if (currentName.isNotEmpty()) {
                        val (streamUrl, inlineHeaders, inlineDrmInfo) = parseInlineMetadata(trimmedLine)

                        val finalHeaders = currentHeaders.toMutableMap()
                        finalHeaders.putAll(inlineHeaders)

                        channels.add(M3uChannel(
                            name        = currentName,
                            logoUrl     = currentLogo,
                            streamUrl   = streamUrl,
                            groupTitle  = currentGroup,
                            userAgent   = currentUserAgent,
                            httpHeaders = finalHeaders,
                            drmScheme   = inlineDrmInfo.first  ?: currentDrmScheme,
                            drmKeyId    = inlineDrmInfo.second ?: currentDrmKeyId,
                            drmKey      = inlineDrmInfo.third  ?: currentDrmKey
                        ))

                        currentDrmScheme = null
                        currentDrmKeyId  = null
                        currentDrmKey    = null
                    }
                }
            }
        }

        return channels
    }

    private fun parseInlineMetadata(urlLine: String): Triple<String, Map<String, String>, Triple<String?, String?, String?>> {
        val headers    = mutableMapOf<String, String>()
        var drmScheme: String? = null
        var drmKeyId: String?  = null
        var drmKey: String?    = null

        var cleanUrl = urlLine.trim()

        val pipeParamMatch = PIPE_PARAM_PATTERN.find(cleanUrl)
        if (pipeParamMatch != null) {
            try {
                val headerKey    = pipeParamMatch.groupValues[2].trim()
                val decodedValue = java.net.URLDecoder.decode(pipeParamMatch.groupValues[3], "UTF-8")
                when (headerKey.lowercase()) {
                    "cookie"               -> headers["Cookie"]        = decodedValue
                    "referer","referrer"   -> headers["Referer"]       = decodedValue
                    "user-agent","useragent" -> headers["User-Agent"]  = decodedValue
                    "origin"               -> headers["Origin"]        = decodedValue
                    "authorization","auth" -> headers["Authorization"] = decodedValue
                }
                cleanUrl = cleanUrl.replace(pipeParamMatch.value, "")
            } catch (e: Exception) {}
        }

        for ((_, pattern) in BASE64_PARAM_PATTERNS) {
            val match = pattern.find(cleanUrl) ?: continue
            try {
                val encoded = match.groupValues[1]
                val decoded = try {
                    String(Base64.decode(encoded, Base64.URL_SAFE or Base64.NO_WRAP))
                } catch (e: Exception) {
                    String(Base64.decode(encoded, Base64.DEFAULT))
                }
                when {
                    decoded.startsWith("{") && decoded.endsWith("}") -> {
                        try {
                            val json = JSONObject(decoded)
                            json.keys().forEach { key -> headers[key] = json.optString(key, "") }
                            cleanUrl = cleanUrl.replace(match.value, "")
                        } catch (e: Exception) {}
                    }
                    decoded.contains("=") -> {
                        val decodedParts = decoded.split(AMP_SPLIT_PATTERN)
                        var foundHeaders = false
                        for (part in decodedParts) {
                            val eqIndex = part.indexOf('=')
                            if (eqIndex == -1) continue
                            val key   = part.substring(0, eqIndex).trim()
                            val value = part.substring(eqIndex + 1).trim()
                            when (key.lowercase()) {
                                "cookie"               -> { headers["Cookie"]        = value; foundHeaders = true }
                                "referer","referrer"   -> { headers["Referer"]       = value; foundHeaders = true }
                                "user-agent","useragent" -> { headers["User-Agent"]  = value; foundHeaders = true }
                                "origin"               -> { headers["Origin"]        = value; foundHeaders = true }
                                "authorization","auth" -> { headers["Authorization"] = value; foundHeaders = true }
                            }
                        }
                        if (foundHeaders) cleanUrl = cleanUrl.replace(match.value, "")
                    }
                }
            } catch (e: Exception) {}
        }

        val jsonMatch = JSON_HEADER_PATTERN.find(cleanUrl)
        if (jsonMatch != null) {
            try {
                val encodedJson = jsonMatch.groupValues[2]
                val decodedJson = if (encodedJson.startsWith("%")) {
                    java.net.URLDecoder.decode(encodedJson, "UTF-8")
                } else encodedJson
                val json = JSONObject(decodedJson)
                json.keys().forEach { key -> headers[key] = json.optString(key, "") }
                cleanUrl = cleanUrl.replace(jsonMatch.value, "")
            } catch (e: Exception) {}
        }

        val multipleCookies = mutableListOf<String>()
        var cookieMatch = COOKIE_MULTI_PATTERN.find(cleanUrl)
        while (cookieMatch != null) {
            try {
                val value = java.net.URLDecoder.decode(cookieMatch.groupValues[2], "UTF-8")
                multipleCookies.add(value)
                cleanUrl = cleanUrl.replace(cookieMatch.value, "")
            } catch (e: Exception) {}
            cookieMatch = COOKIE_MULTI_PATTERN.find(cleanUrl)
        }
        if (multipleCookies.isNotEmpty()) {
            headers["Cookie"] = multipleCookies.joinToString("; ")
        }

        val hashIndex = cleanUrl.indexOf('#')
        if (hashIndex != -1) {
            val hashParts = cleanUrl.substring(hashIndex + 1).split('&')
            for (part in hashParts) {
                val eqIndex = part.indexOf('=')
                if (eqIndex == -1) continue
                val key   = part.substring(0, eqIndex).trim()
                val value = part.substring(eqIndex + 1).trim()
                when (key.lowercase()) {
                    "cookie"                     -> headers["Cookie"]    = value
                    "apikey","api-key","api_key" -> headers["X-API-Key"] = value
                }
            }
            cleanUrl = cleanUrl.substring(0, hashIndex)
        }

        var doubleColonMatch = DOUBLE_COLON_PATTERN.find(cleanUrl)
        while (doubleColonMatch != null) {
            try {
                val key   = doubleColonMatch.groupValues[1].trim()
                val value = doubleColonMatch.groupValues[2].trim()
                when (key.lowercase()) {
                    "cookie"               -> headers["Cookie"]        = value
                    "referer","referrer"   -> headers["Referer"]       = value
                    "user-agent","useragent","ua" -> headers["User-Agent"] = value
                    "origin"               -> headers["Origin"]        = value
                    "authorization","auth" -> headers["Authorization"] = value
                }
                cleanUrl = cleanUrl.replace(doubleColonMatch.value, "")
            } catch (e: Exception) {}
            doubleColonMatch = DOUBLE_COLON_PATTERN.find(cleanUrl)
        }

        val semicolonIndex = cleanUrl.indexOf(';')
        if (semicolonIndex != -1 && !cleanUrl.contains('|')) {
            val urlPart      = cleanUrl.substring(0, semicolonIndex).trim()
            val paramsString = cleanUrl.substring(semicolonIndex + 1).trim()
            if (paramsString.isNotEmpty()) {
                var foundHeaders = false
                for (part in paramsString.split(';')) {
                    val eqIndex = part.indexOf('=')
                    if (eqIndex == -1) continue
                    val key   = part.substring(0, eqIndex).trim()
                    val value = part.substring(eqIndex + 1).trim()
                    when (key.lowercase()) {
                        "cookie"               -> { headers["Cookie"]    = value; foundHeaders = true }
                        "referer","referrer"   -> { headers["Referer"]   = value; foundHeaders = true }
                        "user-agent","useragent","ua" -> { headers["User-Agent"] = value; foundHeaders = true }
                        "origin"               -> { headers["Origin"]    = value; foundHeaders = true }
                    }
                }
                if (foundHeaders) cleanUrl = urlPart
            }
        }

        val customSeparators = listOf("$", "@@", "##", "%%")
        for (separator in customSeparators) {
            val sepIndex = cleanUrl.indexOf(separator)
            if (sepIndex != -1 && !cleanUrl.contains('|')) {
                val urlPart      = cleanUrl.substring(0, sepIndex).trim()
                val paramsString = cleanUrl.substring(sepIndex + separator.length).trim()
                if (paramsString.isNotEmpty()) {
                    var foundHeaders = false
                    for (part in paramsString.split(separator)) {
                        val eqIndex = part.indexOf('=')
                        if (eqIndex == -1) continue
                        val key   = part.substring(0, eqIndex).trim()
                        val value = part.substring(eqIndex + 1).trim()
                        when (key.lowercase()) {
                            "cookie"               -> { headers["Cookie"]        = value; foundHeaders = true }
                            "referer","referrer"   -> { headers["Referer"]       = value; foundHeaders = true }
                            "user-agent","useragent","ua" -> { headers["User-Agent"] = value; foundHeaders = true }
                            "origin"               -> { headers["Origin"]        = value; foundHeaders = true }
                            "authorization","auth" -> { headers["Authorization"] = value; foundHeaders = true }
                        }
                    }
                    if (foundHeaders) { cleanUrl = urlPart; break }
                }
            }
        }

        val (urlAfterQuery, queryHeaders) = extractHeadersFromQueryParams(cleanUrl)
        headers.putAll(queryHeaders)
        cleanUrl = urlAfterQuery

        cleanUrl = cleanUrl.replace(TRAILING_SEP_PATTERN, "")

        val pipeIndex = cleanUrl.indexOf('|')
        if (pipeIndex != -1) {
            val urlPart      = cleanUrl.substring(0, pipeIndex).trim()
            val paramsString = cleanUrl.substring(pipeIndex + 1).trim()

            if (paramsString.isNotEmpty()) {
                for (part in paramsString.split(PIPE_SPLIT_PATTERN)) {
                    val trimmedPart = part.trim()
                    if (trimmedPart.isEmpty()) continue
                    val eqIndex = trimmedPart.indexOf('=')
                    if (eqIndex == -1) continue
                    val key   = trimmedPart.substring(0, eqIndex).trim()
                    val value = trimmedPart.substring(eqIndex + 1).trim()

                    when (key.lowercase()) {
                        "drmscheme","drm-scheme","drm_scheme","drm" -> drmScheme = normalizeDrmScheme(value)
                        "drmlicense","drm-license","drm_license","license","lic" -> {
                            if (value.startsWith("http://", ignoreCase = true) ||
                                value.startsWith("https://", ignoreCase = true)) {
                                drmKeyId = value
                                drmKey   = "LICENSE_URL"
                            } else {
                                val colonIndex = value.indexOf(':')
                                if (colonIndex != -1) {
                                    drmKeyId = value.substring(0, colonIndex).trim()
                                    drmKey   = value.substring(colonIndex + 1).trim()
                                }
                            }
                        }
                        "drmkey","drm-key","drm_key","kid" -> drmKeyId = value
                        "key","k"                          -> if (drmKeyId != null) drmKey = value
                        "user-agent","useragent","user_agent","ua" -> headers["User-Agent"] = value
                        "referer","referrer","ref"         -> headers["Referer"]        = value
                        "origin","org"                     -> headers["Origin"]         = value
                        "cookie","cookies"                 -> if (!headers.containsKey("Cookie")) headers["Cookie"] = value
                        "x-forwarded-for","x_forwarded_for","xff" -> headers["X-Forwarded-For"] = value
                        "authorization"                    -> headers["Authorization"]  = if (value.startsWith("Bearer ", ignoreCase = true)) value else "Bearer $value"
                        "content-type","content_type","ct" -> headers["Content-Type"]  = value
                        "accept","acc"                     -> headers["Accept"]         = value
                        "range"                            -> headers["Range"]          = value
                        "host"                             -> headers["Host"]           = value
                        "connection","conn"                -> headers["Connection"]     = value
                        "cache-control","cache_control"    -> headers["Cache-Control"]  = value
                        "pragma"                           -> headers["Pragma"]         = value
                        "upgrade-insecure-requests"        -> headers["Upgrade-Insecure-Requests"] = value
                        "sec-fetch-site"                   -> headers["Sec-Fetch-Site"] = value
                        "sec-fetch-mode"                   -> headers["Sec-Fetch-Mode"] = value
                        "sec-fetch-dest"                   -> headers["Sec-Fetch-Dest"] = value
                        "apikey","api-key","api_key"        -> headers["X-API-Key"]     = value
                        else -> if (key.startsWith("x-", ignoreCase = true) ||
                                    key.startsWith("sec-", ignoreCase = true) ||
                                    key.contains("-")) {
                            headers[key] = value
                        }
                    }
                }
            }

            return Triple(urlPart, headers, Triple(drmScheme, drmKeyId, drmKey))
        }

        return Triple(cleanUrl, headers, Triple(drmScheme, drmKeyId, drmKey))
    }

    private fun extractChannelName(line: String): String {
        val lastComma = line.lastIndexOf(',')
        return if (lastComma != -1 && lastComma < line.length - 1) {
            line.substring(lastComma + 1).trim()
        } else {
            "Unknown Channel"
        }
    }

    private fun extractAttribute(line: String, attribute: String): String {
        val (quoted, unquoted) = attributePatterns(attribute)
        val match = quoted.find(line)
        if (match != null) return match.groupValues[1]
        return unquoted.find(line)?.groupValues?.get(1) ?: ""
    }

    private fun normalizeDrmScheme(scheme: String): String {
        val lower = scheme.lowercase()
        return when {
            lower.contains("clearkey") || lower == "org.w3.clearkey" || lower == "cenc" -> "clearkey"
            lower.contains("widevine") || lower == "com.widevine.alpha"                 -> "widevine"
            lower.contains("playready") || lower == "com.microsoft.playready"           -> "playready"
            lower.contains("fairplay") || lower == "com.apple.fps" || lower == "fps"   -> "fairplay"
            lower.contains("marlin")      -> "marlin"
            lower.contains("primetime") || lower.contains("adobe") -> "primetime"
            lower.contains("verimatrix")  -> "verimatrix"
            lower.contains("securemedia") -> "securemedia"
            lower.contains("irdeto")      -> "irdeto"
            lower.contains("nagra")       -> "nagra"
            else -> lower
        }
    }

    private fun extractHeadersFromQueryParams(url: String): Pair<String, Map<String, String>> {
        val headers  = mutableMapOf<String, String>()
        var cleanUrl = url

        for ((_, pair) in COMMON_HEADER_PATTERNS) {
            val (headerName, pattern) = pair
            val match = pattern.find(cleanUrl) ?: continue
            try {
                val value = java.net.URLDecoder.decode(match.groupValues[1], "UTF-8")
                if (headerName == "Authorization") {
                    headers[headerName] = when {
                        value.startsWith("Bearer ", ignoreCase = true)                  -> value
                        value.contains(".") && value.split(".").size == 3               -> "Bearer $value"
                        else                                                             -> "Bearer $value"
                    }
                } else {
                    headers[headerName] = value
                }
                cleanUrl = cleanUrl.replace(match.value, "")
            } catch (e: Exception) {}
        }

        cleanUrl = cleanUrl.replace(TRAILING_SEP_PATTERN, "").replace(QUESTION_AMP_PATTERN, "?")
        return Pair(cleanUrl, headers)
    }

    private fun decodeJWT(token: String): Map<String, String>? {
        return try {
            val parts = token.split(".")
            if (parts.size != 3) return null
            val payload       = parts[1]
            val paddedPayload = payload + "=".repeat((4 - payload.length % 4) % 4)
            val decoded       = String(Base64.decode(paddedPayload.replace("-", "+").replace("_", "/"), Base64.DEFAULT))
            val json          = JSONObject(decoded)
            val result        = mutableMapOf<String, String>()
            json.keys().forEach { key -> result[key] = json.optString(key, "") }
            result
        } catch (e: Exception) { null }
    }

    private fun detectStreamType(url: String): String {
        return when {
            url.contains(".m3u8", ignoreCase = true) || url.contains("/hls/", ignoreCase = true)      -> "HLS"
            url.contains(".mpd", ignoreCase = true)  || url.contains("/dash/", ignoreCase = true)     -> "DASH"
            url.contains(".ism", ignoreCase = true)  || url.contains("manifest", ignoreCase = true)   -> "SMOOTH"
            url.contains(".flv", ignoreCase = true)                                                   -> "FLV"
            url.contains("rtmp://", ignoreCase = true) || url.contains("rtmps://", ignoreCase = true) -> "RTMP"
            url.contains(".ts", ignoreCase = true)                                                    -> "TS"
            url.contains(".mp4", ignoreCase = true)                                                   -> "MP4"
            url.contains(".mkv", ignoreCase = true)                                                   -> "MKV"
            else                                                                                       -> "UNKNOWN"
        }
    }

    private fun parseJWKToKeyIdPair(jwk: String): Pair<String?, String?> {
        return try {
            val kidMatch = JWK_KID_PATTERN.find(jwk)
            val kMatch   = JWK_K_PATTERN.find(jwk)
            if (kidMatch != null && kMatch != null) {
                val kidHex = base64UrlToHex(kidMatch.groupValues[1])
                val kHex   = base64UrlToHex(kMatch.groupValues[1])
                if (kidHex.isNotEmpty() && kHex.isNotEmpty()) kidHex to kHex else null to null
            } else {
                null to null
            }
        } catch (e: Exception) { null to null }
    }

    private fun base64UrlToHex(base64Url: String): String {
        return try {
            var base64 = base64Url.replace('-', '+').replace('_', '/')
            base64 += "=".repeat((4 - (base64.length % 4)) % 4)
            val bytes = try {
                Base64.decode(base64, Base64.NO_WRAP)
            } catch (e: Exception) {
                Base64.decode(base64, Base64.URL_SAFE or Base64.NO_WRAP)
            }
            bytes.joinToString("") { "%02x".format(it) }
        } catch (e: Exception) { "" }
    }

    private fun generateChannelId(streamUrl: String, name: String): String {
        val combined = "$streamUrl|$name"
        return try {
            val digest = MessageDigest.getInstance("MD5").digest(combined.toByteArray())
            digest.joinToString("") { "%02x".format(it) }
        } catch (e: Exception) {
            "m3u_${combined.hashCode()}"
        }
    }

    fun convertToChannels(
        m3uChannels: List<M3uChannel>,
        categoryId: String,
        categoryName: String
    ): List<Channel> {
        return m3uChannels.map { m3u ->
            val metaUrl = buildStreamUrlWithMetadata(m3u)
            Channel(
                id           = generateChannelId(m3u.streamUrl, m3u.name),
                name         = m3u.name,
                logoUrl      = m3u.logoUrl,
                streamUrl    = metaUrl,
                categoryId   = categoryId,
                categoryName = categoryName,
                groupTitle   = m3u.groupTitle
            )
        }
    }

    private fun buildStreamUrlWithMetadata(m3u: M3uChannel): String {
        val parts = mutableListOf<String>()
        parts.add(m3u.streamUrl)
        m3u.userAgent?.let { parts.add("User-Agent=$it") }
        m3u.httpHeaders.forEach { (key, value) -> parts.add("$key=$value") }
        if (m3u.drmScheme != null) {
            parts.add("drmScheme=${m3u.drmScheme}")
            if (m3u.drmKeyId != null && m3u.drmKey != null) {
                if (m3u.drmKeyId.startsWith("http://", ignoreCase = true) ||
                    m3u.drmKeyId.startsWith("https://", ignoreCase = true)) {
                    parts.add("drmLicense=${m3u.drmKeyId}")
                } else {
                    parts.add("drmLicense=${m3u.drmKeyId}:${m3u.drmKey}")
                }
            }
        }
        return if (parts.size > 1) parts.joinToString("|") else parts[0]
    }
}
